@extends('layouts.app')


@section('content')
<!-- Content -->
<main class="s-layout__content">
  <div class="container containoutn">
<h1 class="head1new ">Completed Ticket Forms
</h1>
<div class="row">
  <div class="col-lg-12 mt-2">
    <select name="" id="" class="form-control slec1">
      <option value="">AECOM Building</option>
      <option value="">Apple Building</option>
    </select>
  </div>
  <div class="col-lg-12 mt-3">
    <select name="" id="" class="form-control slec1">
      <option value="">AECOM Building</option>
      <option value="">Apple Building</option>
    </select>
  </div>
</div>
<div class="row">
  <div class="col-lg-3 col-md-3 col-sm-12 col-12 text-center mt-5">
    <div class="cmplformd">
      <img src="assets/miniform.b11b3881.png" alt="">
    </div>
          <h1 class="cmplfrmimh">Master Bath</h1>
      <p class="cmplfrmimp">(1 jan 2021 - 7 jan 2021)</p>
  </div>
  <div class="col-lg-3 col-md-3 col-sm-12 col-12 text-center mt-5">
    <div class="cmplformd">
      <img src="assets/miniform.b11b3881.png" alt="">
    </div>
          <h1 class="cmplfrmimh">Master Bath</h1>
      <p class="cmplfrmimp">(1 jan 2021 - 7 jan 2021)</p>
  </div>
  <div class="col-lg-3 col-md-3 col-sm-12 col-12 text-center mt-5">
    <div class="cmplformd">
      <img src="assets/miniform.b11b3881.png" alt="">
    </div>
          <h1 class="cmplfrmimh">Master Bath</h1>
      <p class="cmplfrmimp">(1 jan 2021 - 7 jan 2021)</p>
  </div>
  <div class="col-lg-3 col-md-3 col-sm-12 col-12 text-center mt-5">
    <div class="cmplformd">
      <img src="assets/miniform.b11b3881.png" alt="">
    </div>
          <h1 class="cmplfrmimh">Master Bath</h1>
      <p class="cmplfrmimp">(1 jan 2021 - 7 jan 2021)</p>
  </div>
</div>
  </div>
</main>
</div>
@endsection