@extends('layouts.app')


@section('content')
<!-- Content -->
<main class="s-layout__content">
  <div class="container containoutn">
<h1 class="head1new ml-3">Ticket Forms</h1>
@if(Session::has('success'))
<div class="alert alert-success">
    {{ Session::get('success') }}
    @php
        Session::forget('success');
    @endphp
</div>
@endif
<table class="table bg-white mt-5">
  <thead>
    <tr>
      <th class="tablehead text-left" style="width: 8%;" scope="col">#</th>
      <th class="tablehead text-left" style="width: 84%;" scope="col">Project Name</th>
      <th class="tablehead text-left" style="width: 8%;">View <br> Details</th>
    </tr>
  </thead>
  @foreach($orders as $order)
  <tbody>
    <tr>
      <th class="tabledata text-left">{{$order->id}}</th>
      <td class="tabledata text-left">{{$order->project}}</td>
      <td class="tablehead text-left"><a href="{{route('tickets.form.edit',$order->id)}}"><i class="fa fa-edit"></a></i></td>
    </tr>
  @endforeach
  </tbody>
</table>
  </div>
</main>
</div>
  @endsection