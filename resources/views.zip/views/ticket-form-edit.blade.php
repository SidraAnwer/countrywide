@extends('layouts.app')


@section('content')
      <!-- Content -->
      <main class="s-layout__content">
        <div class="container containoutn">
          <h1 class="head1new ">Edit Ticket Form</h1>
          <form action="{{route('tickets.form.update',$orders->id)}}" method="POST">
          {{ csrf_field() }}
              <div class="row">
                <div class="col-lg-12 mt-2">
                  <select name="" id="" class="form-control slec1">
                    <option value="">AECOM Building</option>
                    <option value="">Apple Building</option>
                  </select>
                </div>
              </div>
              <div class="row mt-5 addfrmouter">
                <div class="col-lg-12 text-center pb-3">
                  <p class="cmplfrmimp">222 Varick Avenue</p>
                  <p class="cmplfrmimp">Brooklyn, NY 11237</p>
                  <p class="cmplfrmimp">(718) 635-4022</p>
                  <a href="">www.countrywidestone.com</a>
                </div>
                <div class="col-lg-12 text-center pt-2" style="border-top:4px solid #9B870C;border-bottom:4px solid #9B870C;">
                  <p class="cmplfrmimp font-weight-bolder">TIME AND MATERIALS EXTRA WORK ORDER FORM</p>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-12">
                  <div class="form-group mt-1">
                    <label for="">Date:</label><input type="text" class="addfrminp">
                  </div>
                </div>
                <div class="col-lg-4  col-md-4 col-sm-12">
                  <div class="form-group mt-1">
                    <label for="">Ticket No:</label><input type="text" name="ticket_no" value="{{$orders->ticket_no}}" class="addfrminp">
                  </div>
                </div>
                <div class="col-lg-4  col-md-4 col-sm-12 inpemp"></div>
                <div class="col-lg-4 col-md-4 col-sm-12">
                  <div class="form-group mt-1">
                    <label for="">Project:</label><input type="text" name="project" value="{{$orders->project}}" class="addfrminp">
                  </div>
                </div>
                <div class="col-lg-4  col-md-4 col-sm-12">
                  <div class="form-group mt-1">
                    <label for="">Job No:</label><input type="text" name="job_no" value="{{$orders->job_no}}" class="addfrminp">
                  </div>
                </div>
                <div class="col-lg-4  col-md-4 col-sm-12 inpemp"></div>
                <div class="col-lg-4  col-md-4 col-sm-12">
                  <div class="form-group mt-1">
                    <label for="">Contractor:</label><input type="text" name="constractor" value="{{$orders->constractor}}" class="addfrminp">
                  </div>
                </div>
                <div class="col-lg-12 pt-2" style="border-top:4px solid black;border-bottom:4px solid black;">
                  <p class="cmplfrmimp font-weight-bolder">The following work is to be performed and paid in accordance with the contract terms:</p>
                  <div class="form-group mt-1">
                    <label for="" class="font-weight-bolder">Description:</label><input type="text" class="addfrminp">
                  </div>
                </div>
                @foreach($orders->orderDetails as $orderDetail)
                <div class="col-lg-12 text-center pt-2" style="border-top:4px solid black;border-bottom:1px solid black;background-color: #ADD8E6;margin-top: 100px;">
                  <p class="cmplfrmimp font-weight-bolder">Material</p>
                </div>
                <div class="col-lg-12">
                  <table class="table table-bordered text-center table-responsive">
                    <thead>
                      <tr>
                        <th scope="col">Description</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Unit</th>
                        <th scope="col">Total</th>
                        <th scope="col">Color</th>
                        <th scope="col">Notes/Observations</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <input type="text" name="description" value="{{$orderDetail->description}}" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" name="quantity" value="{{$orderDetail->quantity}}" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" name="unit" value="{{$orderDetail->unit}}" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" name="total" value="{{$orderDetail->total}}" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" name="color"  value="{{$orderDetail->color}}" class="addfrminp2">
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                      </tr>
                      
                    </tbody>
                  </table>
                </div>
                <div class="col-lg-12 text-center pt-2" style="border-top:4px solid black;border-bottom:1px solid black;background-color: #ADD8E6;">
                  <p class="cmplfrmimp font-weight-bolder">Labor</p>
                </div>
                <div class="col-lg-12">
                  <table class="table table-bordered text-center table-responsive">
                    <thead>
                      <tr>
                        <th scope="col">Description</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Regular Hours</th>
                        <th scope="col">Premium Hours</th>
                        <th scope="col">OverTime Hours</th>
                        <th scope="col">Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <input type="text" name="labor_description"  value="{{$orderDetail->labor_category}}" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" name="regularly_hours"  value="{{$orderDetail->regularly_hours}}" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" name="premium_hours" value="{{$orderDetail->premium_hours}}" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" name="over_time_hours" value="{{$orderDetail->over_time_hours}}"  class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" name="double_time" value="{{$orderDetail->double_time}}" class="addfrminp2">
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                        <td>
                          <input type="text" class="addfrminp2">
                        </td>
                      </tr>
                      
                    </tbody>
                  </table>
                </div>
                @endforeach
                <div class="col-lg-12" style="margin-bottom: 100px;">
                  <p class="cmplfrmimp">This work is verified for me and material by the CONTRACTOR SUPERINTENDENT,</p>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-12">
                  <input type="text" name="constractor_sup_name" value="{{ $orders->constractor_sup_name }}" class="addfrminp" style="width: 85%;"><br><label>CONTRACTOR SUPERINTENDENT NAME</label>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-12">
                  <input type="text" name="constractor_sup_sign" value="{{$orders->constractor_sup_sign}}"  class="addfrminp" style="width: 85%;"><br><label>CONTRACTOR SUPERINTENDENT Sign</label>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-12">
                  <input type="text" class="addfrminp" style="width: 85%;"><br><label>Date</label>
                </div>
              </div>
              <div class="col-lg-12 py-4 text-right">
                <button class="newaddfrmbtn mr-2">Upload Media</button>
                <button class="newaddfrmbtn2 mr-2" type="submit">Save</button>
              </div>
          </form>
        </div>
      </main>
    </div>
@endsection