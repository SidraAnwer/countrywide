@extends('layouts.app')


@section('content')
      <!-- Content -->
      <main class="s-layout__content">
        <div class="container containoutn" id="containoutn">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-6">
              <h1 class="head1new ml-3">Users</h1></br>
              @include('flash')
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-6 text-right">
              <a href="{{url('add-employee')}}"><button class="btn adduserbtn">+ Add User</button></a>
            </div>
          </div>
          <table class="table mt-5">
            <thead>
              <tr  style="background-color: transparent !important;">
                <th class="tablehead" width="20%" scope="col"></th>
                <th class="tablehead" width="40%" scope="col">Name</th>
                <th class="tablehead" width="30%"  scope="col">Position</th>
                <th class="tablehead text-center" width="10%">View Details</th>
              </tr>
            </thead>
            @foreach($users as $user)
            <tbody class="bg-white">
              <tr style="border-bottom: 5px solid #E6E6E6;">
                <th class="tabledata">
                  <img src="{{asset('assets/images/user.png')}}" class="tableuserimg" alt="">
                </th>
                <th class="tabledata">{{$user->name}}</th>
              
                <td class="tabledata">{{$user->role->name}}</td>
              
                <td class="tablehead text-center">
                  <div class="dropdown">
                    <button class="btn tabledrp dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" >
                    </button>
                    <div class="dropdown-menu mt-3" style="margin-right: 150px;" aria-labelledby="dropdownMenuButton">
                      <a class="dropdown-item" href="#">x &nbsp Remove</a>
                    </div>
                  </div>
                </td>
              </tr>
           
            </tbody>
            @endforeach
          </table>
        </div>
      </main>
    </div>
 @endsection