@extends('layouts.app')


@section('content')
<!-- Content -->
<main class="s-layout__content">
  <div class="container containoutn" id="containoutn">
    
<h1 class="head1new ">Place Order</h1>
<div class="row">
  <div class="col-lg-12 mt-2">
    <select name="" id="" class="form-control slec1">
      <option value="">AECOM Building</option>
      <option value="">Apple Building</option>
    </select>
  </div>
  <div class="col-lg-12">
<table id="myTable" class="table bg-white mt-5 ">
  <thead>
    <tr>
      <th class="tablehead text-left"  scope="col">#</th>
      <th class="tablehead text-left"  scope="col">Name</th>
      <th class="tablehead text-left"  scope="col">Color</th>
      <th class="tablehead text-left"  scope="col">Size</th>
      <th class="tablehead text-left"  scope="col">Quantity</th>
      <th class="tablehead text-left"  scope="col">Units</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th class="tabledata text-left">1</th>
      <td class="tabledata text-left">
        <select class="newseleplaceor" name="" id="">
          <option value="">Select Name</option>
        @foreach($materials as $material)
          <option value="{{$material->description}}">{{$material->description}}</option>
         @endforeach
        </select>
      </td>
<td class="tabledata text-left">
        <select class="newseleplaceor" name="" id="">
          <option value="">Select Color</option>
        @foreach($materials as $material)
          <option value="{{$material->color}}">{{$material->color}}</option>
          @endforeach
        </select>
      </td>
<td class="tabledata text-left">
        <select class="newseleplaceor" name="" id="">
        <option value="">Select Size</option>
        @foreach($materials as $material)
          <option value="{{$material->size}}">{{$material->size}}</option>
          @endforeach
        </select>
      </td>
<td class="tabledata text-left">
        <select class="newseleplaceor" name="" id="">
        <option value="">Select Quantity</option>
        @foreach($materials as $material)
          <option value="{{$material->quantity}}">{{$material->quantity}}</option>
          @endforeach
        </select>
      </td>
<td class="tabledata text-left">
        <select class="newseleplaceor" name="" id="">
        <option value="">Select Unit</option>
        @foreach($materials as $material)
          <option value="{{$material->unit}}">{{$material->unit}}</option>
          @endforeach
        </select>
      </td>

    </tr>

  </tbody>
</table>
<button onclick="addTableRow()" class="addrowbtn">+ Add Material</button>
</div>
  <div class="col-lg-12 mt-3">
    <select name="" id="" class="form-control slec1">
      <option value="">Select Email</option>
      <option value="">abc@gmail.com</option>
    </select>
  </div>
  <div class="col-lg-5 mt-4">
    <button class="btn addmaterialbtn1">Place Order</button>
  </div>
</div>

  </div>
</main>
</div>
  @endsection